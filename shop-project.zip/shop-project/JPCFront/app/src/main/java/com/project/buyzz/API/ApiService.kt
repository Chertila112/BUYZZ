package com.project.buyzz.API

import com.project.buyzz.models.Users
import com.project.buyzz.models.Cart
import com.project.buyzz.models.CartItems
import com.project.buyzz.models.OrderItems
import com.project.buyzz.models.OrderStatusHistory
import com.project.buyzz.models.Orders
import com.project.buyzz.models.Products

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface ApiService {
    // Users
    @GET("/api/users")
    suspend fun getUsers(): Response<List<Users>>

    @POST("/auth/login")
    suspend fun login(
        @Body request: Map<String, String>
    ): Response<Map<String, Any>>

    @POST("/auth/register")
    suspend fun register(@Body request: Map<String, String>): Response<Map<String, Any>>

    @GET("/api/users/{id}")
    suspend fun getUser(@Path("id") id: Int): Response<Users>

    // Products
    @GET("/api/products")
    suspend fun getProducts(): Response<List<Products>>

    @POST("/api/products")
    suspend fun createProduct(@Body product: Products): Response<String>

    // Cart
    @GET("/api/cart/{userId}")
    suspend fun getCart(@Path("userId") userId: Int): Response<Cart>

    @GET("/api/cart/{userId}/items")
    suspend fun getCartItems(@Path("userId") userId: Int): Response<List<CartItems>>

    @POST("/api/cart/{userId}/items")
    suspend fun addToCart(
        @Path("userId") userId: Int,
        @Body item: CartItems
    ): Response<Unit>

    // Orders
    @GET("/api/orders/{userId}")
    suspend fun getUserOrders(@Path("userId") userId: Int): Response<List<Orders>>

    @GET("/api/orders/{orderId}/items")
    suspend fun getOrderItems(@Path("orderId") orderId: Int): Response<List<OrderItems>>

    @GET("/api/orders/{orderId}/history")
    suspend fun getOrderHistory(@Path("orderId") orderId: Int): Response<List<OrderStatusHistory>>

    @POST("/api/orders")
    suspend fun createOrder(@Body order: Orders): Response<Orders>
}